1. OPEN Loader.exe 
2. Open game